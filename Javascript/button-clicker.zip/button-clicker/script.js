function logOut(element) {
    element.innerText = "Logout";
}

function hide(element) {
    element.remove();
}